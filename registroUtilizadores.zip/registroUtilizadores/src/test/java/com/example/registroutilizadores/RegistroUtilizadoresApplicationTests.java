package com.example.registroutilizadores;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegistroUtilizadoresApplicationTests {

    @Test
    void contextLoads() {
    }

}
