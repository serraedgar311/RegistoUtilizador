package com.example.registroutilizadores.controller;

import com.example.registroutilizadores.model.Utilizador;
import com.example.registroutilizadores.service.UtilizadorService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/utilizadores")
public class UtilizadorController {

    private final UtilizadorService utilizadorService;

    public UtilizadorController(UtilizadorService utilizadorService) {
        this.utilizadorService = utilizadorService;
    }

    @GetMapping("/utilizador")
    public List<Utilizador> listaCompleta(){
        return utilizadorService.listarUtilizador();
    }

    @PostMapping("/utilizador")
    public void adicionarUtilizador(@RequestBody Utilizador utilizador){
        utilizadorService.saveUtilizador(utilizador);
    }

    @PutMapping("/utilizador/{id}")
    public Utilizador atualizarUtilizador(
            @PathVariable Long id,
            @RequestBody Utilizador utilizador) {

        return utilizadorService.atualizarUtilizador(id, utilizador);
    }

    @DeleteMapping("/utilizador/{id}")
    public void apagarutilizador(@PathVariable("id") Long id){
        utilizadorService.deleteUtilizador(id);
    }


}
