package com.example.registroutilizadores;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RegistroUtilizadoresApplication {

    public static void main(String[] args) {
        SpringApplication.run(RegistroUtilizadoresApplication.class, args);
    }

}