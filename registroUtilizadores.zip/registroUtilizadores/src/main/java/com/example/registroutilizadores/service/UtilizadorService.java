package com.example.registroutilizadores.service;

import com.example.registroutilizadores.model.Utilizador;
import com.example.registroutilizadores.repository.UtilizadorRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UtilizadorService {

    private final UtilizadorRepository utilizadorRepository;


    public UtilizadorService(UtilizadorRepository utilizadorRepository) {
        this.utilizadorRepository = utilizadorRepository;
    }

    public List<Utilizador> listarUtilizador(){
        return utilizadorRepository.findAll();
    }

    public void saveUtilizador(Utilizador utilizador) {
        utilizadorRepository.save(utilizador);
    }


    public Utilizador atualizarUtilizador(long id, Utilizador utilizador){
        Utilizador utilizadorExistente = utilizadorRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Utilizador não encontrado"));

        utilizadorExistente.setName(utilizador.getName());
        utilizadorExistente.setEmail(utilizador.getEmail());
        utilizadorExistente.setAge(utilizador.getAge());
        return utilizadorExistente;
    }
    public void deleteUtilizador(long id){
        utilizadorRepository.deleteById(id);
    }
}